"""Практическая работа № 2. Сортировка и преобразование одномерных массивов.

Основные задания 1-3 и дополнительные задания 1-3.
Индексы в программе начинаются с 0; «места» в условии нумеруются с 1,
поэтому нечётные места — это индексы 0, 2, 4, ..., чётные места — 1, 3, 5, ...
"""
import random


# ---------- Задание 1. Пузырьковая сортировка по УБЫВАНИЮ ----------
def bubble_sort_desc(a, show=False):
    """Сортирует массив a по убыванию (на месте). Возвращает a."""
    n = len(a)
    for i in range(n - 1):                 # внешний цикл: n-1 проходов
        for j in range(n - 1 - i):         # внутренний: до неотсортированной части
            if a[j] < a[j + 1]:            # было «>» для возрастания, стало «<»
                a[j], a[j + 1] = a[j + 1], a[j]
        if show:
            print(f"Проход {i + 1}:", *a)
    return a


# ---------- Задание 2. Проверка упорядоченности по убыванию ----------
def is_sorted_desc(a):
    """True, если a[0] >= a[1] >= ... >= a[n-1]."""
    for i in range(len(a) - 1):
        if a[i] < a[i + 1]:
            return False
    return True


def check_and_sort_desc(a):
    """Проверяет последовательность; если не упорядочена по убыванию — упорядочивает."""
    if is_sorted_desc(a):
        print("Последовательность уже упорядочена по убыванию.")
    else:
        print("Последовательность НЕ упорядочена по убыванию, выполняется сортировка.")
        bubble_sort_desc(a)
    return a


# ---------- Задание 3. Пузырьковая сортировка чётных элементов ----------
def bubble_sort_even(a):
    """Сортирует по возрастанию только чётные элементы массива.
    Нечётные элементы остаются на своих местах, чётные переставляются
    между «чётными» позициями."""
    idx = [i for i in range(len(a)) if a[i] % 2 == 0]   # позиции чётных элементов
    k = len(idx)
    for i in range(k - 1):
        for j in range(k - 1 - i):
            if a[idx[j]] > a[idx[j + 1]]:
                a[idx[j]], a[idx[j + 1]] = a[idx[j + 1]], a[idx[j]]
    return a


# ---------- Доп. задание 1. Нечётные места — по возрастанию, чётные — по убыванию ----------
def bubble_sort_step(a, start, descending):
    """Пузырёк по элементам a[start], a[start+2], a[start+4], ... (шаг 2)."""
    n = len(a)
    last = n - 1 if (n - 1 - start) % 2 == 0 else n - 2   # последний индекс подпоследовательности
    count = (last - start) // 2 + 1 if last >= start else 0
    for i in range(count - 1):
        for j in range(count - 1 - i):
            p, q = start + 2 * j, start + 2 * j + 2
            wrong = a[p] < a[q] if descending else a[p] > a[q]
            if wrong:
                a[p], a[q] = a[q], a[p]


def odd_asc_even_desc(a):
    bubble_sort_step(a, 0, descending=False)   # места 1, 3, 5, ... — по возрастанию
    bubble_sort_step(a, 1, descending=True)    # места 2, 4, 6, ... — по убыванию
    return a


# ---------- Доп. задание 2. Удаление повторяющихся элементов ----------
def remove_duplicates(a):
    """Оставляет в массиве по одному экземпляру каждого значения (первое вхождение),
    «поджимая» массив к началу без дополнительного массива.
    Возвращает новую длину k; значимая часть массива — a[:k]."""
    k = 1                                   # a[0..k-1] — уже отобранные уникальные
    for i in range(1, len(a)):
        found = False
        for j in range(k):                  # ищем a[i] среди отобранных
            if a[i] == a[j]:
                found = True
                break
        if not found:
            a[k] = a[i]
            k += 1
    return k if a else 0


# ---------- Доп. задание 3. Единицы, затем двойки, затем нули ----------
def ones_twos_zeros(a):
    """Переставляет элементы 0/1/2 так: сначала 1, затем 2, затем 0.
    Один проход, без дополнительного массива (три указателя)."""
    low, mid, high = 0, 0, len(a) - 1
    while mid <= high:
        if a[mid] == 1:                     # единицу — в начало
            a[low], a[mid] = a[mid], a[low]
            low += 1
            mid += 1
        elif a[mid] == 2:                   # двойка уже в середине
            mid += 1
        else:                               # ноль — в конец
            a[mid], a[high] = a[high], a[mid]
            high -= 1
    return a


# ---------- Автоматическая проверка ----------
def run_tests(trials=2000):
    random.seed(2)
    for _ in range(trials):
        n = random.randint(0, 15)
        a = [random.randint(-9, 9) for _ in range(n)]

        b = a.copy(); bubble_sort_desc(b)
        assert b == sorted(a, reverse=True)

        b = a.copy(); check_and_sort_desc_silent(b)
        assert b == sorted(a, reverse=True)

        b = a.copy(); bubble_sort_even(b)
        ev = sorted(x for x in a if x % 2 == 0)
        it = iter(ev)
        assert b == [next(it) if x % 2 == 0 else x for x in a]

        b = a.copy(); odd_asc_even_desc(b)
        assert b[0::2] == sorted(a[0::2]) and b[1::2] == sorted(a[1::2], reverse=True)

        b = a.copy(); k = remove_duplicates(b)
        expected = list(dict.fromkeys(a))
        assert b[:k] == expected

        c = [random.choice((0, 1, 2)) for _ in range(n)]
        d = ones_twos_zeros(c.copy())
        assert d == [1] * c.count(1) + [2] * c.count(2) + [0] * c.count(0)
    print(f"Автотест: {trials} случайных массивов, все 6 алгоритмов — без ошибок.")


def check_and_sort_desc_silent(a):
    if not is_sorted_desc(a):
        bubble_sort_desc(a)
    return a


# ---------- Демонстрация ----------
def demo():
    print("=== Задание 1. Сортировка по убыванию ===")
    a = [30, 53, 11, 35, 17, 42, 21, 84, 75, 61]
    print("Исходный массив:", *a)
    bubble_sort_desc(a, show=True)
    print("Отсортированный по убыванию:", *a)

    print("\n=== Задание 2. Проверка упорядоченности по убыванию ===")
    for a in ([9, 7, 7, 5, 3, 1], [4, 9, 7, 6, 2, 3]):
        print("Массив:", *a)
        check_and_sort_desc(a)
        print("Результат:", *a)

    print("\n=== Задание 3. Сортировка чётных элементов ===")
    a = [4, 9, 7, 6, 2, 3, 8, 5, 10]
    print("Исходный массив:", *a)
    bubble_sort_even(a)
    print("После сортировки чётных:", *a)

    print("\n=== Доп. задание 1. Нечётные места — по возрастанию, чётные — по убыванию ===")
    a = [5, 1, 2, 4, 6, 3, 9]
    print("Исходный массив:", *a)
    odd_asc_even_desc(a)
    print("Результат:", *a)

    print("\n=== Доп. задание 2. Удаление повторов ===")
    a = [3, 1, 3, 2, 1, 5, 2, 3]
    print("Исходный массив:", *a)
    k = remove_duplicates(a)
    print("Новая длина:", k)
    print("Массив после удаления повторов:", *a[:k])

    print("\n=== Доп. задание 3. Сначала 1, затем 2, затем 0 ===")
    a = [2, 0, 1, 1, 0, 2, 1, 0, 2, 1]
    print("Исходный массив:", *a)
    ones_twos_zeros(a)
    print("Результат:", *a)

    print()
    run_tests()


if __name__ == "__main__":
    demo()
